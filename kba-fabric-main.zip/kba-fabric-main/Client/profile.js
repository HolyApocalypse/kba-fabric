let profile = {
    manufacturer : {
        "Wallet" : "../Network/vars/profiles/vscode/wallets/manufacturer.auto.com",
        "CP" : "../Network/vars/profiles/autochannel_connection_for_nodesdk.json"
    },
    dealer : {
        "Wallet" : "../Network/vars/profiles/vscode/wallets/dealer.auto.com",
        "CP" : "../Network/vars/profiles/autochannel_connection_for_nodesdk.json"

    },
    mvd : {
        "Wallet" : "../Network/vars/profiles/vscode/wallets/dealer.auto.com",
        "CP" : "../Network/vars/profiles/autochannel_connection_for_nodesdk.json"

    }
}

module.exports = {
    profile
}